/*
 * C++ program to Implement AVL Tree
 */
#include<iostream>
using namespace std;

/*
 * Node Declaration
 */
template<typename T> class avl_node {

public:
	T data;
	avl_node *left;
	avl_node *right;
};

/*
 * Class Declaration
 */
template<typename T> class AVLTree {
public:

	//tree manipulation functions
	int height(avl_node<T> *);
	int diff(avl_node<T> *);
	avl_node<T> *rr_rotation(avl_node<T> *);
	avl_node<T> *ll_rotation(avl_node<T> *);
	avl_node<T> *lr_rotation(avl_node<T> *);
	avl_node<T> *rl_rotation(avl_node<T> *);
	avl_node<T>* balance(avl_node<T> *);
	avl_node<T>* insert(avl_node<T> *, T);
	void replace(avl_node<T> *tree, T key);

	//tree display functions
	void display(avl_node<T> *, int);
	void inorder(avl_node<T> *, ostream& anyStream);
	void preorder(avl_node<T> *);
	void postorder(avl_node<T> *);

	//accessors and mutators
	void setRoot(avl_node<T> *);
	void setRootRight(avl_node<T> *);
	avl_node<T>* getRoot();
	T findMin(avl_node<T> *);
	avl_node<T>* find(avl_node<T> *, T);

	//constructor
	AVLTree(){
		root = nullptr;
		numNodes = 0;
	}
private:
	//root of the tree
	avl_node<T> *root;
	//number of nodes
	int numNodes;
};

/*
 * Height of AVL Tree
 */
template<typename T> int AVLTree<T>::height(avl_node<T> *temp) {
	int h = 0;
	if (temp != nullptr) {
		int l_height = height(temp->left);
		int r_height = height(temp->right);
		int max_height = max(l_height, r_height);
		h = max_height + 1;
	}
	return h;
}

/*
 * Height Difference
 */
template<typename T> int AVLTree<T>::diff(avl_node<T> *temp) {
	int l_height = height(temp->left);
	int r_height = height(temp->right);
	int b_factor = l_height - r_height;
	return b_factor;
}

/*
 * Right- Right Rotation
 */
template<typename T> avl_node<T> *AVLTree<T>::rr_rotation(avl_node<T> *parent) {
	avl_node<T> *temp;
	temp = parent->right;
	parent->right = temp->left;
	temp->left = parent;
	return temp;
}
/*
 * Left- Left Rotation
 */
template<typename T> avl_node<T> *AVLTree<T>::ll_rotation(avl_node<T> *parent) {
	avl_node<T> *temp;
	temp = parent->left;
	parent->left = temp->right;
	temp->right = parent;
	return temp;
}

/*
 * Left - Right Rotation
 */
template<typename T> avl_node<T> *AVLTree<T>::lr_rotation(avl_node<T> *parent) {
	avl_node<T> *temp;
	temp = parent->left;
	parent->left = rr_rotation(temp);
	return ll_rotation(parent);
}

/*
 * Right- Left Rotation
 */
template<typename T> avl_node<T> *AVLTree<T>::rl_rotation(avl_node<T> *parent) {
	avl_node<T> *temp;
	temp = parent->right;
	parent->right = ll_rotation(temp);
	return rr_rotation(parent);
}

/*
 * Balancing AVL Tree
 */
template<typename T> avl_node<T> *AVLTree<T>::balance(avl_node<T> *temp) {
	int bal_factor = diff(temp);
	if (bal_factor > 1) {
		if (diff(temp->left) > 0)
			temp = ll_rotation(temp);
		else
			temp = lr_rotation(temp);
	} else if (bal_factor < -1) {
		if (diff(temp->right) > 0)
			temp = rl_rotation(temp);
		else
			temp = rr_rotation(temp);
	}
	return temp;
}

/*
 * Insert Element into the tree
 */
template<typename T> avl_node<T> *AVLTree<T>::insert(avl_node<T> *root, T value) {

	//if no root, create one and increment the number of nodes
	if(root == nullptr){
		root = new avl_node<T>;
		root->data = value;
		root->left = nullptr;
		root->right = nullptr;
		++numNodes;
		return root;
	}
	//if it should go on the left side, insert it there and increment number of nodes
	else if (value < root->data){
		root->left = insert(root->left, value);
		root = balance(root);
		++numNodes;
	}
	//if it should go on the right side, insert it there and increment number of nodes
	else if(value >= root->data){
		root->right = insert(root->right, value);
		root = balance(root);
		++numNodes;
	}
	return root;
}

/*
 * Display AVL Tree
 */
template<typename T> void AVLTree<T>::display(avl_node<T> *ptr, int level) {
	int i;
	if (ptr != nullptr) {
		display(ptr->right, level + 1);
		printf("\n");
		if (ptr == root)
			cout << "Root -> ";
		for (i = 0; i < level && ptr != root; i++)
			cout << "        ";
		cout << ptr->data;
		display(ptr->left, level + 1);
	}
}

/*
 * Inorder Traversal of AVL Tree
 */
template<typename T> void AVLTree<T>::inorder(avl_node<T> *tree, ostream& anyStream) {
	if (tree == nullptr)
		return;
	inorder(tree->left, anyStream);
	anyStream << tree->data << endl;
	inorder(tree->right, anyStream);
}
/*
 * Preorder Traversal of AVL Tree
 */
template<typename T> void AVLTree<T>::preorder(avl_node<T> *tree) {
	if (tree == nullptr)
		return;
	cout << tree->data << endl;
	preorder(tree->left);
	preorder(tree->right);

}

/*
 * Postorder Traversal of AVL Tree
 */
template<typename T> void AVLTree<T>::postorder(avl_node<T> *tree) {
	if (tree == nullptr)
		return;
	postorder(tree->left);
	postorder(tree->right);
	cout << tree->data << endl;
}


//sets the root of the tree to the given node
template<typename T> void AVLTree<T>::setRoot(avl_node<T> *tree) {
	this->root = tree;
}

//sets the right pointer of the root of the tree to the given node
template<typename T> void AVLTree<T>::setRootRight(avl_node<T> *tree) {
	this->root->right = tree;
}

//gets the root
template<typename T> avl_node<T>* AVLTree<T>::getRoot() {
	return this->root;
}

//finds the smallest node on the right side of the tree, given the right subtree
template <typename T> T AVLTree<T>::findMin(avl_node<T> *subtree){



	if(subtree->left != nullptr){
		findMin(subtree->left);
	}
	else{
		return subtree->data;
	}

}

//code based on code from Cavan Gary
template <typename T> avl_node<T>* AVLTree<T>::find(avl_node<T> *subtree, T key){

	//if found, return the node
	if(key == subtree->data){
		return subtree;
	}
	//otherwise, recursively call for the left side
	else if(key < subtree->data){
		if(subtree->left != nullptr){
			find(subtree->left, key);
		}
		else{
			cout << "key not found" << endl;
		}
	}
	//otherwise, recursively call for the right side
	else if(key > subtree->data){
		if(subtree->right != nullptr){
			find(subtree->right, key);
		}
		else{
			cout << "key not found" << endl;
		}
	}

}



//code based on code from Cavan Gary
//replaces the data of the node with matching data (will replace eclipses with matching catalog numbers)
template <typename T> void AVLTree<T>::replace(avl_node<T> *tree, T key){

	if(tree == nullptr){
		return;
	}
	replace(tree->left, key);
	if(tree->data == key){
		tree->data = key;
	}
	replace(tree->right, key);

}
