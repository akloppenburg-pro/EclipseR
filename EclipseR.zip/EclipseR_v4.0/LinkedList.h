/*
 * LinkedList.h
 *
 *  Created on: Oct 27, 2017
 *      Author: Alex
 *
 *      Based on code found at https://www.codementor.io/codementorteam/
 *      a-comprehensive-guide-to-implementation-of-singly-linked-list-using-c_plus_plus-ondlm5azr
 */

#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_
#include <iostream>

namespace std {

template<typename T> class LinkedList {

	//structure allowing the list to have nodes that contain data and point to each other
	struct node{
		T data;
		node *next;
	};

private:
	//two nodes that we use to determine where the list starts and stops
	node *head, *tail;

	//indicates the current size.  Starts numbering at 1, so this must be compensated for in the code.
	int currSize;


public:

	//empty list constructor, initialized all values to 0 or nullptr
	LinkedList(){

		head = nullptr;
		tail = nullptr;
		currSize = 0;

	}

	~LinkedList(){
		//empty destructor
	}

	//inserts a newly created node at the given position, sets its data field to value, and checks for errors
	void createNodeAt(T value, int pos){

		//error checking
		if(pos < 0){
			cerr << "Insert - LinkedList position values must be greater than 0." << endl;
		}

		//if size is 0, this is the first element and thus it becomes head and tail
		if(currSize == 0){

			//creates a new node with 'value' for its data null next value
			node *createdNode = new node;
			createdNode->data = value;
			createdNode->next = nullptr;

			//if the list has no nodes (head is null), assign this one as the head and the tail
			if(head == nullptr){
				head = createdNode;
				tail = createdNode;
				createdNode = nullptr;
			}

			//increment the size
			++currSize;

		}

		//if inserted at index 0, one position before the current head (becomes head)
		else if(pos == 0){

			//creates a new node with 'value' as its data
			node *createdNode = new node;
			createdNode->data = value;
			//inserts it at the head and assigns pointers accordingly
			createdNode->next = head;
			head = createdNode;

			//increment the size
			++currSize;

		}

		//if inserted at end of list, one position after the current tail (becomes tail)
		else if(pos >= currSize){

			//creates a new node, links it to the current tail, and then sets the tail as the created node
			node *createdNode = new node;
			createdNode->data = value;
			tail->next = createdNode;
			tail = createdNode;

			createdNode->next = nullptr;

			//increment the size
			++currSize;

		}

		//insert wherever it's supposed to
		else{

			node *previous = new node;
			node *current = new node;
			node *createdNode = new node;

			//set the head as current node and then iterate through until we reach pos
			current = head;

			//iterate from 0 to pos
			for(int i = 0; i < pos; i++){

				previous = current;
				current = current->next;
			}

			//insert our new node in between previous and current
			createdNode->data = value;
			previous->next = createdNode;
			createdNode->next = current;

			//increment the size
			++currSize;
		}

	}

	//deletes the node at the given position, with appropriate error checking
	void deleteNode(int pos){

		//error checking
		if(pos == 0){
			cerr << "Delete - LinkedList position values must be greater than 0." << endl;
		}
		if(currSize - 1 < 0){
			cerr << "Delete - LinkedList has no more values to delete." << endl;
		}

		//if deleting head (which sits at position 1)
		if(pos == 1){

			//assigns the current head node to a temp variable, the 2nd node as the new head, and deletes the old head
			node *temp = new node;
			temp = head;
			head = head->next;
			delete temp;

			//decrement currSize
			--currSize;

		}

		//if deleting tail (which sits at position currSize)
		else if(pos == currSize){

			//start at head
			node *current = new node;
			node *previous = new node;
			current = head;

			//iterate through from head until we reach tail
			while(current->next != nullptr){
				previous = current;
				current = current->next;
			}

			//set 2nd to last as tail, set its 'next' to null (making it the new tail), and delete the old tail
			tail = previous;
			previous->next = nullptr;
			delete current;

			//decrement currSize
			--currSize;

		}

		//otherwise, delete wherever it's supposed to (at pos)
		else{

			//similar to create, we find the desired node first
			node *current = new node;
			node *previous = new node;
			current = head;

			//iterate through until we get to pos
			for(int i = 0; i < pos; i++){
				previous = current;
				current = current->next;
			}

			//remove current from the list and then deletes it
			previous->next = current->next;
			delete current;

			//decrement currSize
			--currSize;

		}

	}

	//replaces the data  of the node at pos with the given value
	void replaceNode(T value, int pos){

		//error checking
		if(pos < 0){
			cerr << "Replace - LinkedList position values must be greater than 0." << endl;
		}

		//similar to create and delete, we find the desired node first
		node *current = new node;
		current = head;

		//iterate through until we get to pos
		for(int i = 1; i < pos; i++){
			current = current->next;
		}
		//sets the data of the current node (the one at pos) as the given value
		current->data = value;

	}

	//an encapsulated function to display (using cout or other ostream) the entire linked list
	void display(ostream& anyStream){

		//start at head
		node *temp = new node;
		temp = head;

		//iterate through and send each node's data to the given ostream
		while(temp != nullptr){
			anyStream << temp->data << endl;
			temp = temp->next;
		}

		delete temp;
	}

	//a special variant of the display function only for use with LinkedLists when they are used for collision resolution
	//in a hash table
	void displaySeparateChaining(ostream& anyStream){

		//start at head and set a flag
		node *temp = new node;
		temp = head;
		bool firstElement = true;

		//iterate through and send each node's data to the given ostream
		while(temp != nullptr){
			if(firstElement == true){
				anyStream << temp->data << endl;
			}
			else{
				anyStream << "OVERFLOW: " << temp->data << endl;
			}
			temp = temp->next;
		}

		delete temp;

	}

	//copies the list over into a resizeable array for use in searching and sorting
	ResizeableArray<T> listToArray(){

		ResizeableArray<T> myArray;

		node *current = new node;
		current = head;

		for(int i = 0; i < currSize; i++){
			myArray.add(current->data);
			current = current->next;
		}

		return myArray;
	}

	//returns the 'data' field of the node at the given position
	T get(int pos){

		//similar to create, we find the desired node first
		node *current = new node;
		current = head;

		//iterate through until we get to pos
		for(int i = 0; i < pos; i++){
			current = current->next;
		}

		return current->data;
	}

	int length(){
		return currSize;
	}

};

} /* namespace std */

#endif /* LINKEDLIST_H_ */
