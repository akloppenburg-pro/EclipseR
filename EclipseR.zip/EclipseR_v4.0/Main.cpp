/*
 * main.cpp
 *
 *  Created on: Oct 17, 2017
 *      Author: Alex
 */

#include "Main.h"
#include "Eclipse.h"
#include "ResizeableArray.h"
#include "LinkedList.h"
#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

int Main::monthToInt(string month){
	if(month == "Jan"){
		return 1;
	}
	else if(month == "Feb"){
		return 2;
	}
	else if(month == "Mar"){
		return 3;
	}
	else if(month == "Apr"){
		return 4;
	}
	else if(month == "May"){
		return 5;
	}
	else if(month == "Jun"){
		return 6;
	}
	else if(month == "Jul"){
		return 7;
	}
	else if(month == "Aug"){
		return 8;
	}
	else if(month == "Sep"){
		return 9;
	}
	else if(month == "Oct"){
		return 10;
	}
	else if(month == "Nov"){
		return 11;
	}
	else if(month == "Dec"){
		return 12;
	}
}

//checks a given number to see if it is an integer or a decimal
//used several times in the main to check various columns
bool Main::numChecker(string num, char choice){

	//both set as false at the beginning
	bool isWhole = false;
	bool isDecimal = false;

	//if choice == 'w', check to see if it's a whole number
	if(choice == 'w'){

		//if the first character is a '-', it's a negative number and the digit checking starts from the second character
		if(num.at(0) == '-'){

			//cycles through the number and makes sure every character is a digit
			for(unsigned int i = 1; i < num.length(); ++i){
				if(isdigit(num.at(i))){
					isWhole = true;
				}
				else{
					isWhole = false;
				}
			}
		}
		//otherwise, checking starts from the first character
		else{

			//cycles through the number and makes sure every character is a digit
			for(unsigned int i = 0; i < num.length(); ++i){
				if(isdigit(num.at(i))){
					isWhole = true;
				}
				else{
					isWhole = false;
				}
			}
		}

		return isWhole;

	}

	//if choice == 'd', check to see if it's a decimal number
	else if(choice  == 'd'){

		//if there is a decimal point, return true.  otherwise, return false.
		if(num.find('.') != string::npos){
			isDecimal = true;
		}
		else{
			isDecimal = false;
		}

		return isDecimal;

	}

	else{
		return false;
	}
}

//identical function to the one in eclipse class because we need its functionality both inside and outside the eclipse object
string Main::columnSeparator(string data, int columnNum, bool isPartial){

	//number of commas in the line
	int numCommas = 0;


	//the column we're looking for (not initialized bc we do that later)
	int desiredColumn;

	//set to the max possible values
	if(isPartial){
		desiredColumn = 16;
	}
	else{
		desiredColumn = 18;
	}

	for(unsigned int i = 0; i < data.length(); ++i){

		//increments numCommas to find the number of commas in the line
		if(data.at(i) == ','){
			++numCommas;
		}

		//uses three if statements, since the first and last columns aren't "sandwiched" by commas
		//returns everything before the first comma (the first column)
		if(data.at(i) == ',' && columnNum == 1){
			return(data.substr(0, i));
		}
		//returns the last column
		else if(data.at(i) == ',' && columnNum == desiredColumn && numCommas == columnNum - 1){
			return(data.substr(i + 1, data.length() - i - 1));
		}
		//returns the desired column
		else if(data.at(i) == ',' && numCommas == columnNum - 1){
			return(data.substr(i + 1, data.find(',', i + 1) - i - 1));
		}

	}

}

//based on code from http://www.geeksforgeeks.org/merge-sort/
void Main::merge(int left, int mid, int right, int columnNum){
	int i, j, k = 0;
	int leftArraySize = mid - left + 1;
	int rightArraySize =  right - mid;

	/* create temp arrays */
	ResizeableArray<Eclipse> L, R;

	/* Copy data to temp arrays L[] and R[] */
	for (i = 0; i < leftArraySize; i++){
		L.add(dataArray.get(left + i));
	}
	for (j = 0; j < rightArraySize; j++){
		R.add(dataArray.get(mid + 1 + j));
	}

	/* Merge the temp arrays back into arr[l..r]*/
	i = 0; // Initial index of first subarray
	j = 0; // Initial index of second subarray
	k = left; // Initial index of merged subarray
	while (i < leftArraySize && j < rightArraySize){

		//if the column can be an int, cast it as such for comparison purposes, but still sort eclipses
		//extra if to deal with column 18, spaces should go at the end
		if(columnNum == 1 || columnNum == 2 || columnNum == 3 || columnNum == 5 || columnNum == 7 ||
				columnNum == 8 || columnNum == 9 || columnNum == 15 || columnNum == 16){

			try{
				if (stoi(L.get(i).getColumnElement(columnNum)) <= stoi(R.get(j).getColumnElement(columnNum))){
					dataArray.replaceAt(L.get(i), k);
					i++;
				}
				else{
					dataArray.replaceAt(R.get(j), k);
					j++;
				}
				k++;
			}
			catch(invalid_argument& ia){
				cerr << "Unable to cast column" << columnNum << "to int for sorting." << endl;
			}

		}
		//if the column can be a double, cast it as such for comparison purposes, but still sort eclipses
		if(columnNum == 11 || columnNum == 12){

			try{
				if (stod(L.get(i).getColumnElement(columnNum)) <= stod(R.get(j).getColumnElement(columnNum))){
					dataArray.replaceAt(L.get(i), k);
					i++;
				}
				else{
					dataArray.replaceAt(R.get(j), k);
					j++;
				}
				k++;
			}
			catch(invalid_argument& ia){
				cerr << "Unable to cast column" << columnNum << "to double for sorting." << endl;
			}

		}
		//leave columns that should be strings as strings
		if(columnNum == 6 || columnNum == 10 || columnNum == 13 || columnNum == 14){

			if (L.get(i).getColumnElement(columnNum) <= R.get(j).getColumnElement(columnNum)){
				dataArray.replaceAt(L.get(i), k);
				i++;
			}
			else{
				dataArray.replaceAt(R.get(j), k);
				j++;
			}
			k++;

		}
		//if sorting by months, enumerate them to ints for sorting
		if(columnNum == 4){
			int leftMonth = monthToInt(L.get(i).getColumnElement(columnNum));
			int rightMonth = monthToInt(R.get(j).getColumnElement(columnNum));

			if (leftMonth <= rightMonth){
				dataArray.replaceAt(L.get(i), k);
				i++;
			}
			else{
				dataArray.replaceAt(R.get(j), k);
				j++;
			}
			k++;


		}
		//if column 17, cast as int and put all blank spaces at the end
		if(columnNum == 17){

			int leftInt;
			int rightInt;

			if(L.get(i).getColumnElement(columnNum) == ""){
				leftInt = 99999999;
			}
			else{
				try{
					leftInt = stoi(L.get(i).getColumnElement(columnNum));
				}
				catch(invalid_argument& ia){
					cerr << "Unable to cast column " << columnNum << " to int for sorting." << endl;
				}
			}
			if(R.get(j).getColumnElement(columnNum) == ""){
				rightInt = 99999999;
			}
			else{
				try{
					rightInt = stoi(R.get(j).getColumnElement(columnNum));
				}
				catch(invalid_argument& ia){
					cerr << "Unable to cast column " << columnNum << " to int for sorting." << endl;
				}
			}

			if (leftInt <= rightInt){
				dataArray.replaceAt(L.get(i), k);
				i++;
			}
			else{
				dataArray.replaceAt(R.get(j), k);
				j++;
			}
			k++;


		}
		//if column 18, leave as string and put all blank spaces at the end
		if(columnNum == 18){

			string leftString;
			string rightString;

			if(L.get(i).getColumnElement(columnNum) == ""){
				leftString = "~~~~~~~~~~~~~~~";
			}
			else{
				leftString = L.get(i).getColumnElement(columnNum);
			}
			if(R.get(j).getColumnElement(columnNum) == ""){
				rightString = "~~~~~~~~~~~~~~~";
			}
			else{
				rightString = R.get(j).getColumnElement(columnNum);
			}

			if (leftString <= rightString){
				dataArray.replaceAt(L.get(i), k);
				i++;
			}
			else{
				dataArray.replaceAt(R.get(j), k);
				j++;
			}
			k++;

		}
	}

	/* Copy the remaining elements of L[], if there
       are any */
	while (i < leftArraySize){
		dataArray.replaceAt(L.get(i), k);
		i++;
		k++;
	}

	/* Copy the remaining elements of R[], if there
       are any */
	while (j < rightArraySize){
		dataArray.replaceAt(R.get(j), k);
		j++;
		k++;
	}
}

/* l is for left index and r is right index of the
   sub-array of arr to be sorted */
void Main::mergeSort(int left, int right, int columnNum){

	if (left < right){
		// Same as (l+r)/2, but avoids overflow for
		// large l and h
		int mid = left + (right - left)/2;

		// Sort first and second halves
		mergeSort(left, mid, columnNum);
		mergeSort(mid + 1, right, columnNum);

		merge(left, mid, right, columnNum);

		sortedColumn = columnNum;
	}
}

//based off of code found on www.geeksforgeeks.com/binary-search/
int Main::binarySearch(int left, int right, string key, int columnNum){

	if(right >= 1){

		int mid = left + (right - left)/2;

		if (dataArray.get(mid).getColumnElement(columnNum) == key){
			return mid;
		}

		// If element is smaller than mid, then it can only be present
		// in left subarray
		if (dataArray.get(mid).getColumnElement(columnNum) > key){
			return binarySearch(left, mid-1, key, columnNum);
		}

		// Else the element can only be present in right subarray
		else{
			return binarySearch(mid+1, right, key, columnNum);
		}
	}

	//only reach this point if the element is not present
	return -1;
}

//code adapted from code found on http://www.geeksforgeeks.org/binary-search/
//linear searches if the array is unsorted, binary searches if it is sorted
ResizeableArray<Eclipse> Main::find(int left, int right, string key, int columnNum){

	//if the array is sorted on the desired column we can perform a binary search
	if(sortedColumn == columnNum){

		ResizeableArray<Eclipse> results;

		int foundIndex = binarySearch(left, right, key, columnNum);
		int firstIndex = 0;
		int lastIndex = 0;

		bool noMoreMatches = false;

		while(noMoreMatches == false){
			if(dataArray.get(foundIndex - firstIndex).getColumnElement(columnNum) == key){
				++firstIndex;
			}
			else{
				noMoreMatches = true;
				firstIndex = foundIndex - firstIndex + 1;
			}
		}

		noMoreMatches = false;

		while(noMoreMatches == false){
			if(dataArray.get(foundIndex + lastIndex).getColumnElement(columnNum) == key){
				++lastIndex;
			}
			else{
				noMoreMatches = true;
				lastIndex = foundIndex + lastIndex;
			}
		}

		for(int i = firstIndex; i < lastIndex; i++){
			results.add(dataArray.get(i));
		}

		//return all possible results
		return results;

	}
	//otherwise we have to perform a linear search
	else{

		ResizeableArray<Eclipse> results;

		for(int i = 0; i < dataArray.length(); ++i){
			if(dataArray.get(i).getColumnElement(columnNum) == key){
				results.add(dataArray.get(i));
			}
		}

		return results;
	}

}

/*This function is in main to solve the problem of cyclical dependancy: arrayToList needed LinkedList to already be declared,
 * but listToArray needed ResizeableArray to already be declared.  Thus, arrayToList is placed in main, where LinkedList is
 * already declared.  listToArray is placed in the LinkedList class where it can access the node data structure.
 */
LinkedList<Eclipse> arrayToList(ResizeableArray<Eclipse> theArray){

	LinkedList<Eclipse> myList;

	for(int i = 0; i < theArray.length(); i++){
		myList.createNodeAt(theArray.getArray()[i], i);
	}

	return myList;
}

//based on code written by Cavan Gary to solve sorting errors
int Main::linkedListSortedOrder(Eclipse ecl){
	for(int i = dataList.length() - 1;  i >= 0; i--){
		if(ecl.getCatNum() > dataList.get(i).getCatNum()){
			return i + 1;
		}
	}
	return 0;
}

//constructor contains the bulk of the program, a single object is created in the "int main()" function
Main::Main() {

	//Strings to hold user input for both loops
	string filename;
	string userChoice;

	//"Trash" string to hold the first 10 lines and the main eclipse object
	string first10Lines;
	ResizeableArray<string> headerLines;

	//the string used to hold lines read in from the input file
	string dataString;

	//list of unique category numbers and the index we're currently on in that list
	ResizeableArray<string> totalCatNumList;
	int totalCatNumIndex = 0;

	//int to track how many files have been read in
	int fileNum = 1;		//we have to have read in at least one file to have any input

	//tallies for all the stats we're tracking as far as eclipses read in
	int totalLinesAttempted = 0;
	int totalValidEclipses = 0;
	int totalEclipsesInMemory = 0;

	//bool to make sure the headers only get read in once
	bool firstTimeHeaders = true;


	//input loop
	while(true){

		//Prompt for user input and read in the name of a file
		if(fileNum == 1){
			cout << "Please enter the name of the file you would like to read in." << endl;
		}
		else{
			cout << "Please enter the name of the file you would like to read in, or press enter to proceed to"
					<< " the main menu."<< endl;
		}
		getline(cin, filename);

		//exit loop if filename is blank
		if(filename == ""){
			if(fileNum == 1){
				cout << "Please enter the name a file to read in." << endl;
				continue;
			}
			else{
				break;
			}
		}

		//for checking of catNums within the file
		ResizeableArray<string> fileCatNumList;
		int fileCatNumIndex = 0;


		//read in data file with given filename
		ifstream infile(filename);

		//if the filename is valid, perform operations on it
		if(infile.is_open()){

			if(firstTimeHeaders == true){
				//collects first 10 lines
				for(int i = 0; i < 10; ++i) {
					getline(infile, first10Lines);
					headerLines.add(first10Lines);
				}
			}
			else{
				for(int i = 0; i < 10; ++i) {
					getline(infile, first10Lines);
				}
			}

			//set the bool as false so that the headers aren't collected multiple times
			firstTimeHeaders = false;

			//tracks the current row for error checking purposes
			int currentRow = 1;

			//collects each line and creates an eclipse object, then checks it for errors and stores it in the array
			while(getline(infile, dataString)){

				//if the line is empty, exit the loop
				if(dataString == ""){
					break;
				}

				//increment this here for every line that we've attempted
				++totalLinesAttempted;

				string dataSpaces = dataString;

				//turns spaces into commas for CSV processing (adapted from lab 1)
				while(dataString.find(" ") != string::npos){
					dataString.replace(dataString.find(" "), 1, ",");
				}

				//processes out double commas to make it look pretty (adapted from lab 1)
				while(dataString.find(",,") != string::npos){
					dataString.replace(dataString.find(",,"), 2, ",");
				}

				//processes out comma at the beginning (adapted from lab 1)
				if(dataString.at(0) == ','){
					dataString = dataString.substr(1, string::npos);
				}

				//Processes out comma at the end (adapted from lab 1)
				if(dataString.at(dataString.length() - 1) == ','){
					dataString.replace(dataString.length() - 1, 1, "");
				}

				//finds the number of commas in the line
				int numCommas = 0;
				for(unsigned int i = 0; i < dataString.length(); ++i){
					if(dataString.at(i) == ','){
						++numCommas;
					}
				}

				/*here to line 496 checks for number type errors: whther everything that should be an integer is an integer
				 * and everything that should be a decimal is a decimal
				 */
				bool shouldBePartial = true;

				if(numCommas == 15){
					shouldBePartial = true;
				}
				if(numCommas == 17){
					shouldBePartial = false;
				}

				if(!numChecker(columnSeparator(dataString, 1, shouldBePartial), 'w')){
					cerr << "Error in data row " << currentRow << " of file " << fileNum <<
							": Column 1 is not a whole number." << endl;
					++currentRow;
					continue;
				}
				if(!numChecker(columnSeparator(dataString, 2, shouldBePartial), 'w')){
					cerr << "Error in data row " << currentRow << " of file " << fileNum <<
							": Column 2 is not a whole number." << endl;
					++currentRow;
					continue;
				}
				if(!numChecker(columnSeparator(dataString, 3, shouldBePartial), 'w')){
					cerr << "Error in data row " << currentRow << " of file " << fileNum <<
							": Column 3 is not a whole number." << endl;
					++currentRow;
					continue;
				}
				if(!numChecker(columnSeparator(dataString, 5, shouldBePartial), 'w')){
					cerr << "Error in data row " << currentRow << " of file " << fileNum <<
							": Column 5 is not a whole number." << endl;
					++currentRow;
					continue;
				}
				if(!numChecker(columnSeparator(dataString, 7, shouldBePartial), 'w')){
					cerr << "Error in data row " << currentRow << " of file " << fileNum <<
							": Column 7 is not a whole number." << endl;
					++currentRow;
					continue;
				}
				if(!numChecker(columnSeparator(dataString, 8, shouldBePartial), 'w')){
					cerr << "Error in data row " << currentRow << " of file " << fileNum <<
							": Column 8 is not a whole number." << endl;
					++currentRow;
					continue;
				}
				if(!numChecker(columnSeparator(dataString, 9, shouldBePartial), 'w')){
					cerr << "Error in data row " << currentRow << " of file " << fileNum <<
							": Column 9 is not a whole number." << endl;
					++currentRow;
					continue;
				}
				if(!numChecker(columnSeparator(dataString, 15, shouldBePartial), 'w')){
					cerr << "Error in data row " << currentRow << " of file " << fileNum <<
							": Column 15 is not a whole number." << endl;
					++currentRow;
					continue;
				}
				if(!numChecker(columnSeparator(dataString, 16, shouldBePartial), 'w')){
					cerr << "Error in data row " << currentRow << " of file " << fileNum <<
							": Column 16 is not a whole number." << endl;
					++currentRow;
					continue;
				}
				//only executes if there exists > 16 columns
				if(numCommas > 15 && !numChecker(columnSeparator(dataString, 17, shouldBePartial), 'w')){
					cerr << "Error in data row " << currentRow << " of file " << fileNum <<
							": Column 17 is not a whole number." << endl;
					++currentRow;
					continue;
				}

				//two more if statements check columns 11 and 12 to be decimals
				if(!numChecker(columnSeparator(dataString, 11,shouldBePartial), 'd')){
					cerr << "Error in data row " << currentRow << " of file " << fileNum <<
							": Column 11 is not a whole number." << endl;
					++currentRow;
					continue;
				}
				if(!numChecker(columnSeparator(dataString, 12, shouldBePartial), 'd')){
					cerr << "Error in data row " << currentRow << " of file " << fileNum <<
							": Column 12 is not a whole number." << endl;
					++currentRow;
					continue;
				}

				//if there are no number type errors, creates an eclipse object with the given data
				//feed in dataSpaces so we have it for output purposes later
				Eclipse ecl(dataSpaces);

				//check for eclipse length errors
				bool isPartial = ecl.columnLength();

				bool isError = false;

				numCommas = 0;

				for(unsigned int m = 0; m < ecl.getDataCommas().length();  ++m){
					//iterates through and counts commas
					if(ecl.getDataCommas().at(m) == ','){
						++numCommas;
					}
				}

				//error checks 2 possible errors: there should be 16 columns and there aren't, or there should be 18 columns
				//and there aren't
				if(isPartial && numCommas != 15){

					cerr << "Error in data row " << currentRow << " of file " << fileNum << ": " << (numCommas + 1) <<
							" columns found.  Should be 16" << endl;
					isError = true;
				}
				if(!isPartial && numCommas != 17){

					cerr << "Error in data row " << currentRow << " of file " << fileNum << ": " << (numCommas + 1) <<
							" columns found.  Should be 16" << endl;
					isError = true;

				}

				/*if the errorchecker function returns true, skip to the next dataString, otherwise check for duplicate
				 * category numbers
				 */
				if(isError == true){
					++currentRow;
					continue;
				}

				//checks for duplicate category numbers within the file
				int checkedIndex = 0;
				bool duplicateCatNum = false;

				while(checkedIndex <= fileCatNumIndex){

					if(fileCatNumList.get(checkedIndex) == ecl.getCatNum()){
						cerr << "Error in data row " << currentRow << " of file " << fileNum << ": Duplicate category number "
								<< ecl.getCatNum() << ".  Row will be skipped." << endl;
						duplicateCatNum = true;
						break;
					}
					else{
						checkedIndex++;
					}

				}

				//if there's a duplicate, skips the rest of the while loop (basically skips to reading in the next line)
				if(duplicateCatNum == true){
					continue;
				}
				else{
					fileCatNumList.add(ecl.getCatNum());
					++fileCatNumIndex;
				}

				//checks for duplicate category numbers over all files
				checkedIndex = 0;		//reset checkedIndex to 0 to re-search
				duplicateCatNum = false;
				while(checkedIndex <= totalCatNumIndex){

					if(totalCatNumList.get(checkedIndex) == ecl.getCatNum()){

						cerr << "Error in data row " << currentRow << " of file " << fileNum << ": Duplicate category number "
								<< ecl.getCatNum() << ".  Row will be replaced." << endl;
						dataList.replaceNode(ecl, stoi(totalCatNumList.get(checkedIndex)) - 1);
						dataTree.replace(dataTree.getRoot(), ecl);
						duplicateCatNum = true;

						++currentRow;
						break;
					}
					else{
						checkedIndex++;
					}
				}

				if(duplicateCatNum == true){
					continue;
				}
				else{
					totalCatNumList.add(ecl.getCatNum());
					++totalCatNumIndex;
				}

				//all error checking has been performed, so increment valid eclipses
				++totalValidEclipses;

				//add the dataString to the LinkedList, barring any stoi errors
				dataList.createNodeAt(ecl, linkedListSortedOrder(ecl));
				dataTree.setRoot(dataTree.insert(dataTree.getRoot(), ecl));

				//increments row counter
				++currentRow;
			}//this is the main while loop here

			//increment the number to track files read in
			++fileNum;
		}

		//else, inform the user that the file couldn't be read in
		else{
			cout << "File is not available." << endl;
		}


		//close the input file at the end
		infile.close();
	}

	//after everything is read into the list, copy it all over to the array
	dataArray = dataList.listToArray();

	dataTable = HashTable<Eclipse>(dataArray, dataList);

	//set the number of current eclipses in memory as the number of eclipses in the list
	totalEclipsesInMemory = dataList.length();

	//data manipulation loop
	while(userChoice != "Q" && userChoice != "q"){

		//prompt for user input
		cout << "Please enter the character corresponding to the option you would like to perform:" << endl <<
				"'o' for output, 'c' for output by catalog number order, 'm' for merge, 'p' for purge, 's' for sort, " <<
				"'f' for find, 'h' for output by hash table order, 'l' for output by hash table linked list order, " <<
				endl << "'r' for pre-order traversal of the AVL tree, 't' for post-order traversal of the AVL tree, "
				<< "or 'q' for quit." << endl;

		//collect user input
		getline(cin, userChoice);

		//if user input is not an acceptable letter, re-loop for the user to try again
		if(userChoice != "Q" && userChoice != "q" && userChoice != "O" && userChoice != "o" && userChoice != "S"
				&& userChoice != "s" && userChoice != "F" && userChoice != "f" && userChoice != "c" && userChoice != "C"
						&& userChoice != "m" && userChoice != "M" && userChoice != "p" && userChoice != "P"
								&& userChoice != "h" && userChoice != "H" && userChoice != "l" && userChoice != "L"
										&& userChoice != "r" && userChoice != "R" && userChoice != "t" && userChoice != "T"){
			cout << "Please enter one of the nine options." << endl;
			continue;
		}

		//if user enters r, traverse the AVL tree by pre-order
		if(userChoice == "r" || userChoice == "R"){
			dataTree.preorder(dataTree.getRoot());
		}

		//if user enters t, traverse the AVL tree by post-order
		if(userChoice == "t" || userChoice == "T"){
			dataTree.postorder(dataTree.getRoot());
		}

		//if h or H is input, display hash table order debug
		if(userChoice == "h" || userChoice == "H"){

			string outFilename;

			//query for user input
			cout << "Please enter a filename to output to, or hit enter to output to the console." << endl;

			//accept user input
			getline(cin, outFilename);

			//if the user hits enter, it outputs to the console
			if(outFilename == ""){
				//print out first 10 lines
				headerLines.display(cout);
				//for loop to print out final array
				dataTable.display(cout);
				//output final tallies
				cout << "Data lines read: "<< totalLinesAttempted << "; Valid eclipses read: "
						<< totalValidEclipses << "; Eclipses in memory: " << totalEclipsesInMemory << endl;
			}
			//otherwise, an output to a file is attempted
			else{
				//stream opened
				ofstream outfile(outFilename);

				//if the filename is valid, writes to it
				if(outfile.is_open()){
					//write first 10 lines
					headerLines.display(outfile);
					//write data
					dataTable.display(outfile);
					//output final tallies
					outfile << "Data lines read: "<< totalLinesAttempted << "; Valid eclipses read: "
							<< totalValidEclipses << "; Eclipses in memory: " << totalEclipsesInMemory << endl;
				}
				//otherwise, tell the user and exit
				else{
					cout << "File is not accessible" << endl;
					continue;
				}

			}

		}

		//if l is input, iterate through the linkedList within the hash table
		if(userChoice == "l" || userChoice == "L"){

			string outFilename;

			//query for user input
			cout << "Please enter a filename to output to, or hit enter to output to the console." << endl;

			//accept user input
			getline(cin, outFilename);

			//if the user hits enter, it outputs to the console
			if(outFilename == ""){
				//print out first 10 lines
				headerLines.display(cout);
				//since the hash table inherits from LinkedList, display prints out its embedded LinkedList
				dataTable.displayLL(cout);
				//output final tallies
				cout << "Data lines read: "<< totalLinesAttempted << "; Valid eclipses read: "
						<< totalValidEclipses << "; Eclipses in memory: " << totalEclipsesInMemory << endl;
			}
			//otherwise, an output to a file is attempted
			else{
				//stream opened
				ofstream outfile(outFilename);

				//if the filename is valid, writes to it
				if(outfile.is_open()){
					//write first 10 lines
					headerLines.display(outfile);
					//write data
					dataTable.displayLL(outfile);
					//output final tallies
					outfile << "Data lines read: "<< totalLinesAttempted << "; Valid eclipses read: "
							<< totalValidEclipses << "; Eclipses in memory: " << totalEclipsesInMemory << endl;
				}
				//otherwise, tell the user and exit
				else{
					cout << "File is not accessible" << endl;
					continue;
				}

			}

		}

		//if user inputs c or C the list is displayed in sorted column order
		if(userChoice == "c" || userChoice == "c"){

			string outFilename;

			//query for user input
			cout << "Please enter a filename to output to, or hit enter to output to the console." << endl;

			//accept user input
			getline(cin, outFilename);

			//if the user hits enter, it outputs to the console
			if(outFilename == ""){
				//print out first 10 lines
				headerLines.display(cout);
				//for loop to print out final array
				dataTree.inorder(dataTree.getRoot(), cout);
				//output final tallies
				cout << "Data lines read: "<< totalLinesAttempted << "; Valid eclipses read: "
						<< totalValidEclipses << "; Eclipses in memory: " << totalEclipsesInMemory << endl;

			}
			//otherwise, an output to a file is attempted
			else{
				//stream opened
				ofstream outfile(outFilename);

				//if the filename is valid, writes to it
				if(outfile.is_open()){
					//write first 10 lines
					headerLines.display(outfile);
					//write data
					dataTree.inorder(dataTree.getRoot(), outfile);
					//output final tallies
					outfile << "Data lines read: "<< totalLinesAttempted << "; Valid eclipses read: "
							<< totalValidEclipses << "; Eclipses in memory: " << totalEclipsesInMemory << endl;
				}
				//otherwise, tell the user and exit
				else{
					cout << "File is not accessible" << endl;
					continue;
				}

			}


		}

		//if user inputs s or S, the sorting method is called and a fresh resizeable array is needed
		if(userChoice == "s" || userChoice == "S"){

			string sortField;

			//prompt for data
			cout << "Please choose the data field you would like to sort by. (1-18)" << endl;

			//get user input
			getline(cin, sortField);

			//check and see if it's within the constraints
			try{
				if(stoi(sortField) > 18 || stoi(sortField) < 1){
					cout << "Please select 's' again and enter a number between 1 and 18." << endl;
					continue;
				}
			}
			catch(const invalid_argument& ia){
				cout << "Please select 's' again and enter a number between 1 and 18." << endl;
				continue;
			}

			//we can omit the try catch block here because we already know it can be made an int
			int sortInt = stoi(sortField);

			//if the array is not sorted over the current column, re-copy it and then sort
			if(sortInt != sortedColumn){
				mergeSort(0, dataArray.length() - 1, sortInt);
			}
			else{
				cout << "The data is already sorted over this column, please select another." << endl;
				continue;
			}

			cout << "Successful sort completed." << endl;

		}

		//if user inputs f or F, the find method is called
		if(userChoice == "f" || userChoice == "F"){

			string findField;
			int findInt;
			string keyString;


			cout << "Please choose the data field you would like to search by. (1-18)" << endl;

			getline(cin, findField);

			if(findField == ""){
				cout << "Please enter a data field to search by." << endl;
				continue;
			}

			try{
				if(stoi(findField) > 18 || stoi(findField) < 1){
					cout << "Please select 'f' again and enter a number between 1 and 18." << endl;
					continue;
				}
			}
			catch(const invalid_argument& ia){
				cout << "Please select 'f' again and enter a number between 1 and 18." << endl;
				continue;
			}

			//we can omit the try-catch block here because we've already tested and found that the given number works
			findInt = stoi(findField);

			//query for user input
			cout << "Please enter the string you'd like to search by." << endl;

			//accept user input
			getline(cin, keyString);

			//tries turning the key into an into for use with the hash map
			int keyInt;
			if(keyString == "1"){
				try{
					keyInt = stoi(keyString);
				}
				catch(const invalid_argument& ia){
					cerr << "Search key is not a number." << endl;
				}
			}


			ResizeableArray<Eclipse> results;
			//searches within the hash table if they're doing column 1
			if(findInt == 1){

				//write first 10 lines
				headerLines.display(cout);
				//couts the eclipse if it works, returns -1 if not
				int catalogValue = dataTable.search(keyInt);

				if(catalogValue == -1){
					cout << "No values match your search." << endl;
				}
				else{
					//then output the summary line
					cout << endl << "Eclipses found: 1" << endl;
				}
			}
			//otherwise searches by the find method
			else{
				cout << "not hash" << endl;

				results = find(0, dataArray.length() - 1, keyString, findInt);

				if(results.length() == 0){
					cout << "No values match your search." << endl;
				}
				else{
					//write first 10 lines
					headerLines.display(cout);
					//output results one by one
					results.display(cout);
					//then output the summary line
					cout << "Eclipses found: " << results.length() << endl;
				}
			}



		}

		//if the user chooses o, output the dataArray (in most cases sorted)
		if(userChoice == "o" || userChoice == "O"){

			//if the array is empty, copy one over from the linkedList
			if(dataArray.length() == 0){
				dataArray = dataList.listToArray();
			}

			string outFilename;

			//query for user input
			cout << "Please enter a filename to output to, or hit enter to output to the console." << endl;

			//accept user input
			getline(cin, outFilename);

			//if the user hits enter, it outputs to the console
			if(outFilename == ""){
				//print out first 10 lines
				headerLines.display(cout);
				//for loop to print out final array
				dataArray.display(cout);
				//output final tallies
				cout << "Data lines read: "<< totalLinesAttempted << "; Valid eclipses read: "
						<< totalValidEclipses << "; Eclipses in memory: " << totalEclipsesInMemory << endl;
			}
			//otherwise, an output to a file is attempted
			else{
				//stream opened
				ofstream outfile(outFilename);

				//if the filename is valid, writes to it
				if(outfile.is_open()){
					//write first 10 lines
					headerLines.display(outfile);
					//write data
					dataArray.display(outfile);
					//output final tallies
					outfile << "Data lines read: "<< totalLinesAttempted << "; Valid eclipses read: "
							<< totalValidEclipses << "; Eclipses in memory: " << totalEclipsesInMemory << endl;
				}
				//otherwise, tell the user and exit
				else{
					cout << "File is not accessible" << endl;
					continue;
				}

			}


		}

		//if the user chooses m, perform a merge operation on the linked list
		if(userChoice == "m" || userChoice == "M"){

			//Prompt for user input and read in the name of a file
			cout << "Please enter the name of the file you would like to read in and merge." << endl;
			getline(cin, filename);

			//exit to main loop if filename is blank
			if(filename == ""){
				cout << "Please enter a filename." << endl;
				continue;
			}

			//for checking of catNums within the file
			ResizeableArray<string> fileCatNumList;
			int fileCatNumIndex = 0;


			//read in data file with given filename
			ifstream infile(filename);

			//if the filename is valid, perform operations on it
			if(infile.is_open()){

				//first 10 lines are already read in during main file input so we trash them here
				for(int i = 0; i < 10; ++i) {
					getline(infile, first10Lines);
				}

				//tracks the current row for error checking purposes
				int currentRow = 1;

				//collects each line and creates an eclipse object, then checks it for errors and performs a merge
				while(getline(infile, dataString)){

					string dataSpaces = dataString;

					//if the line is empty, exit the loop
					if(dataString == ""){
						break;
					}

					//increment this here for every line that we've attempted
					++totalLinesAttempted;

					//turns spaces into commas for CSV processing (adapted from lab 1)
					while(dataString.find(" ") != string::npos){
						dataString.replace(dataString.find(" "), 1, ",");
					}

					//processes out double commas to make it look pretty (adapted from lab 1)
					while(dataString.find(",,") != string::npos){
						dataString.replace(dataString.find(",,"), 2, ",");
					}

					//processes out comma at the beginning (adapted from lab 1)
					if(dataString.at(0) == ','){
						dataString = dataString.substr(1, string::npos);
					}

					//Processes out comma at the end (adapted from lab 1)
					if(dataString.at(dataString.length() - 1) == ','){
						dataString.replace(dataString.length() - 1, 1, "");
					}

					//finds the number of commas in the line
					int numCommas = 0;
					for(unsigned int i = 0; i < dataString.length(); ++i){
						if(dataString.at(i) == ','){
							++numCommas;
						}
					}

					/*checks for number type errors: whether everything that should be an integer is an integer
					 * and everything that should be a decimal is a decimal
					 */
					bool shouldBePartial = true;

					if(numCommas == 15){
						shouldBePartial = true;
					}
					if(numCommas == 17){
						shouldBePartial = false;
					}

					if(!numChecker(columnSeparator(dataString, 1, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 1 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 2, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 2 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 3, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 3 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 5, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 5 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 7, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 7 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 8, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 8 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 9, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 9 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 15, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 15 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 16, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 16 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					//only executes if there exists > 16 columns
					if(numCommas > 15 && !numChecker(columnSeparator(dataString, 17, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 17 is not a whole number." << endl;
						++currentRow;
						continue;
					}

					//two more if statements check columns 11 and 12 to be decimals
					if(!numChecker(columnSeparator(dataString, 11,shouldBePartial), 'd')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 11 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 12, shouldBePartial), 'd')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 12 is not a whole number." << endl;
						++currentRow;
						continue;
					}

					//if there are no number type errors, creates an eclipse object with the given data
					Eclipse ecl(dataSpaces);

					//check for eclipse length errors
					bool isPartial = ecl.columnLength();

					bool isError = false;

					numCommas = 0;

					for(unsigned int m = 0; m < ecl.getDataCommas().length();  ++m){
						//iterates through and counts commas
						if(ecl.getDataCommas().at(m) == ','){
							++numCommas;
						}
					}

					//error checks 2 possible errors: there should be 16 columns and there aren't, or there should be 18 columns
					//and there aren't
					if(isPartial && numCommas != 15){

						cerr << "Error in data row " << currentRow << " of file " << fileNum << ": " << (numCommas + 1) <<
								" columns found.  Should be 16" << endl;
						isError = true;
					}
					if(!isPartial && numCommas != 17){

						cerr << "Error in data row " << currentRow << " of file " << fileNum << ": " << (numCommas + 1) <<
								" columns found.  Should be 16" << endl;
						isError = true;

					}

					/*if the errorchecker function returns true, skip to the next dataString, otherwise check for duplicate
					 * category numbers
					 */
					if(isError == true){
						++currentRow;
						continue;
					}

					//checks for duplicate category numbers within the file
					int checkedIndex = 0;
					bool duplicateCatNum = false;

					while(checkedIndex <= fileCatNumIndex){

						if(fileCatNumList.get(checkedIndex) == ecl.getCatNum()){
							cerr << "Error in data row " << currentRow << " of file" << fileNum <<
									": Duplicate category number " << ecl.getCatNum() << ".  Row will be skipped." << endl;
							duplicateCatNum = true;
							break;
						}
						else{
							checkedIndex++;
						}

					}

					//if there's a duplicate, skips the rest of the while loop (basically skips to reading in the next line)
					if(duplicateCatNum == true){
						continue;
					}
					else{
						fileCatNumList.add(ecl.getCatNum());
						++fileCatNumIndex;
					}

					checkedIndex = 0;		//reset checkedIndex to 0 to re-search
					bool hasBeenMerged = false;
					//uses same loop as file input but omits the continue, since we want to delete on purpose
					while(checkedIndex <= totalCatNumIndex){
						if(totalCatNumList.get(checkedIndex) == ecl.getCatNum()){

							dataTree.replace(dataTree.getRoot(), ecl);
							try{
								dataList.replaceNode(ecl, stoi(totalCatNumList.get(checkedIndex)));
							}
							catch(invalid_argument& ia){
								cerr << "merge catalog number is not an integer" << endl;
							}

							hasBeenMerged = true;
							break;
						}
						else{
							checkedIndex++;
						}
					}

					if(hasBeenMerged == false){
						cout << "No match for data line " << currentRow << " in merge file.  Line will be skipped." << endl;
					}

					//all error checking has been performed, so increment valid eclipses
					++totalValidEclipses;

					//increments row counter
					++currentRow;
				}//this is the main while loop here

				//increment the number to track files read in
				++fileNum;

				cout << "Successful merge completed." << endl;
			}

			//else, inform the user that the file couldn't be read in
			else{
				cout << "File is not available." << endl;
			}

			//close the input file at the end
			infile.close();

			//then create a new dataArray and hash table
			dataArray = dataList.listToArray();
			dataTable.reallocateData(dataArray, dataList);
		}

		//if the user chooses m, perform a purge operation on the linked list
		if(userChoice == "p" || userChoice == "P"){

			//Prompt for user input and read in the name of a file
			cout << "Please enter the name of the file you would like to read in and purge." << endl;
			getline(cin, filename);

			//exit to main loop if filename is blank
			if(filename == ""){
				cout << "Please enter a filename." << endl;
				continue;
			}

			//for checking of catNums within the file
			ResizeableArray<string> fileCatNumList;
			int fileCatNumIndex = 0;


			//read in data file with given filename
			ifstream infile(filename);

			//if the filename is valid, perform operations on it
			if(infile.is_open()){

				//first 10 lines are already read in during main file input so we trash them here
				for(int i = 0; i < 10; ++i) {
					getline(infile, first10Lines);
				}

				//tracks the current row for error checking purposes
				int currentRow = 1;

				//collects each line and creates an eclipse object, then checks it for errors and performs a merge
				while(getline(infile, dataString)){

					//if the line is empty, exit the loop
					if(dataString == ""){
						break;
					}

					string dataSpaces = dataString;

					//increment this here for every line that we've attempted
					++totalLinesAttempted;

					//turns spaces into commas for CSV processing (adapted from lab 1)
					while(dataString.find(" ") != string::npos){
						dataString.replace(dataString.find(" "), 1, ",");
					}

					//processes out double commas to make it look pretty (adapted from lab 1)
					while(dataString.find(",,") != string::npos){
						dataString.replace(dataString.find(",,"), 2, ",");
					}

					//processes out comma at the beginning (adapted from lab 1)
					if(dataString.at(0) == ','){
						dataString = dataString.substr(1, string::npos);
					}

					//Processes out comma at the end (adapted from lab 1)
					if(dataString.at(dataString.length() - 1) == ','){
						dataString.replace(dataString.length() - 1, 1, "");
					}

					//finds the number of commas in the line
					int numCommas = 0;
					for(unsigned int i = 0; i < dataString.length(); ++i){
						if(dataString.at(i) == ','){
							++numCommas;
						}
					}

					/*checks for number type errors: whether everything that should be an integer is an integer
					 * and everything that should be a decimal is a decimal
					 */
					bool shouldBePartial = true;

					if(numCommas == 15){
						shouldBePartial = true;
					}
					if(numCommas == 17){
						shouldBePartial = false;
					}

					if(!numChecker(columnSeparator(dataString, 1, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 1 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 2, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 2 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 3, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 3 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 5, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 5 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 7, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 7 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 8, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 8 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 9, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 9 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 15, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 15 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 16, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 16 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					//only executes if there exists > 16 columns
					if(numCommas > 15 && !numChecker(columnSeparator(dataString, 17, shouldBePartial), 'w')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 17 is not a whole number." << endl;
						++currentRow;
						continue;
					}

					//two more if statements check columns 11 and 12 to be decimals
					if(!numChecker(columnSeparator(dataString, 11,shouldBePartial), 'd')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 11 is not a whole number." << endl;
						++currentRow;
						continue;
					}
					if(!numChecker(columnSeparator(dataString, 12, shouldBePartial), 'd')){
						cerr << "Error in data row " << currentRow << " of file " << fileNum <<
								": Column 12 is not a whole number." << endl;
						++currentRow;
						continue;
					}

					//if there are no number type errors, creates an eclipse object with the given data
					Eclipse ecl(dataSpaces);

					//check for eclipse length errors
					bool isPartial = ecl.columnLength();

					bool isError = false;

					numCommas = 0;

					for(unsigned int m = 0; m < ecl.getDataCommas().length();  ++m){
						//iterates through and counts commas
						if(ecl.getDataCommas().at(m) == ','){
							++numCommas;
						}
					}

					//error checks 2 possible errors: there should be 16 columns and there aren't, or there should be 18 columns
					//and there aren't
					if(isPartial && numCommas != 15){

						cerr << "Error in data row " << currentRow << " of file " << fileNum << ": " << (numCommas + 1) <<
								" columns found.  Should be 16" << endl;
						isError = true;
					}
					if(!isPartial && numCommas != 17){

						cerr << "Error in data row " << currentRow << " of file " << fileNum << ": " << (numCommas + 1) <<
								" columns found.  Should be 16" << endl;
						isError = true;

					}

					/*if the errorchecker function returns true, skip to the next dataString, otherwise check for duplicate
					 * category numbers
					 */
					if(isError == true){
						++currentRow;
						continue;
					}

					//checks for duplicate category numbers within the file
					int checkedIndex = 0;
					bool duplicateCatNum = false;

					while(checkedIndex <= fileCatNumIndex){

						if(fileCatNumList.get(checkedIndex) == ecl.getCatNum()){
							cerr << "Error in data row " << currentRow << " of file" << fileNum <<
									": Duplicate category number " << ecl.getCatNum() << ".  Row will be skipped." << endl;
							duplicateCatNum = true;
							break;
						}
						else{
							checkedIndex++;
						}

					}

					//if there's a duplicate, skips the rest of the while loop (basically skips to reading in the next line)
					if(duplicateCatNum == true){
						continue;
					}
					else{
						fileCatNumList.add(ecl.getCatNum());
						++fileCatNumIndex;
					}

					checkedIndex = 0;		//reset checkedIndex to 0 to re-search
					bool hasBeenPurged = false;
					//uses same loop as file input but omits the continue, since we want to delete on purpose
					while(checkedIndex <= totalCatNumIndex){
						if(totalCatNumList.get(checkedIndex) == ecl.getCatNum()){
							dataList.deleteNode(stoi(totalCatNumList.get(checkedIndex)));
							hasBeenPurged = true;
							break;
						}
						else{
							checkedIndex++;
						}
					}

					if(hasBeenPurged == false){
						cout << "No match for data line " << currentRow << " in purge file.  Line will be skipped." << endl;
					}

					//all error checking has been performed, so increment valid eclipses
					++totalValidEclipses;

					//increments row counter
					++currentRow;
				}//this is the main while loop here

				//increment the number to track files read in
				++fileNum;

				cout << "Successful purge completed." << endl;
			}

			//else, inform the user that the file couldn't be read in
			else{
				cout << "File is not available." << endl;
			}

			//close the input file at the end
			infile.close();

			//then create a new dataArray
			dataArray = dataList.listToArray();
			dataTable.reallocateData(dataArray, dataList);
		}

	}

	//friendly exit message
	cout << "Thank you for using EclipseR_v4.0!  Goodbye!" << endl;

}

Main::~Main(){
	//empty destructor
}

//creates a single Main object, which then executes the entire program by itself
int main(){
	Main main;

	return 0;
}
