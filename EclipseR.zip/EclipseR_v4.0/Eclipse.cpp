/*
 * Eclipse.cpp
 *
 * A class to hold an eclipse read in from a file and all its data, as well as methods to access, manipulate, and output
 * the data.
 *
 *  Created on: Oct 17, 2017
 *  Author: Alex
 */

#include <string>
#include <iomanip>
#include <iostream>
#include <fstream>
#include "Eclipse.h"

namespace std {

//turns the data string into acceptable CSV format and then separates 16-18 columns from it depending on the string
Eclipse::Eclipse(string dataString){

	//sets this field for use during output
	this->dataSpaces = dataString;

	//proceeds with CSV separation for internal handling
	//turns spaces into commas for CSV processing (adapted from lab 1)
	while(dataString.find(" ") != string::npos){
		dataString.replace(dataString.find(" "), 1, ",");
	}

	//processes out double commas to make it look pretty (adapted from lab 1)
	while(dataString.find(",,") != string::npos){
		dataString.replace(dataString.find(",,"), 2, ",");
	}

	//processes out comma at the beginning (adapted from lab 1)
	if(dataString.at(0) == ','){
		dataString = dataString.substr(1, string::npos);
	}

	//Processes out comma at the end (adapted from lab 1)
	if(dataString.at(dataString.length() - 1) == ','){
		dataString.replace(dataString.length() - 1, 1, "");
	}

	//once comma processing is complete, this field is set to the modified string
	this->dataCommas = dataString;

	//determines whether the eclipse in question should be 16 or 18 columns (a partial or not partial eclipse)
	bool isPartial = columnLength();

	//sets all 18 column fields accordingly by separating the comma-modified data string
	this->catNum = columnSeparator(dataString, 1, isPartial);
	this->canonPlate = columnSeparator(dataString, 2, isPartial);
	this->calYear = columnSeparator(dataString, 3, isPartial);
	this->calMonth = columnSeparator(dataString, 4, isPartial);
	this->calDate = columnSeparator(dataString, 5, isPartial);
	this->tD = columnSeparator(dataString, 6, isPartial);
	this->dT = columnSeparator(dataString, 7, isPartial);
	this->lunaNum = columnSeparator(dataString, 8, isPartial);
	this->sarosNum = columnSeparator(dataString, 9, isPartial);
	this->eclType = columnSeparator(dataString, 10, isPartial);
	this->gamma = columnSeparator(dataString, 11, isPartial);
	this->eclMag = columnSeparator(dataString, 12, isPartial);
	this->latitude = columnSeparator(dataString, 13, isPartial);
	this->longitude = columnSeparator(dataString, 14, isPartial);
	this->sunAlt = columnSeparator(dataString, 15, isPartial);
	this->sunAzm = columnSeparator(dataString, 16, isPartial);
	//these are set to empty strings in all cases
	this->pathWidth = "";
	this->centralDur = "";

	//if the eclipse is not partial, they are re-set to their respective values
	if(isPartial == false){
		this->pathWidth = columnSeparator(dataString, 17, isPartial);
		this->centralDur = columnSeparator(dataString, 18, isPartial);
	}
}

//empty constructor sets all fields to empty strings
Eclipse::Eclipse() {
	this->dataSpaces = "";
	this->dataCommas = "";
	this->catNum = "";
	this->canonPlate = "";
	this->calYear = "";
	this->calMonth = "";
	this->calDate = "";
	this->tD = "";
	this->dT = "";
	this->lunaNum = "";
	this->sarosNum = "";
	this->eclType = "";
	this->gamma = "";
	this->eclMag = "";
	this->latitude = "";
	this->longitude = "";
	this->sunAlt = "";
	this->sunAzm = "";
	this->pathWidth = "";
	this->centralDur = "";
}

//copy constructor copies each element over to the new Eclipse
Eclipse::Eclipse(const Eclipse& e){
	this->dataSpaces = e.dataSpaces;
	this->dataCommas = e.dataCommas;
	this->catNum = e.catNum;
	this->canonPlate = e.canonPlate;
	this->calYear = e.calYear;
	this->calMonth = e.calMonth;
	this->calDate = e.calDate;
	this->tD = e.tD;
	this->dT = e.dT;
	this->lunaNum = e.lunaNum;
	this->sarosNum = e.sarosNum;
	this->eclType = e.eclType;
	this->gamma = e.gamma;
	this->eclMag = e.eclMag;
	this->latitude = e.latitude;
	this->longitude = e.longitude;
	this->sunAlt = e.sunAlt;
	this->sunAzm = e.sunAzm;
	this->pathWidth = e.pathWidth;
	this->centralDur = e.centralDur;
}

Eclipse::~Eclipse(){
	//there's nothing to de-allocate so the destructor is empty
}

//accessor that returns the entire data string with spaces for output
string Eclipse::getDataSpaces(){
	return this->dataSpaces;
}

//accessor that returns the entire data string in CSV format for data processing
string Eclipse::getDataCommas(){
	return this->dataCommas;
}

/* accessor that returns column 1, but with 0's added for lexicographical comparison
 * (used when reading into sorted LinkedList)
 *  Cavan Gary assisted with this
 */
string Eclipse::getCatNum(){
	string zeroes;

	if(this->catNum.length() < 5){
		for(int i = 0; i < 5-catNum.length(); i++){
			zeroes += "0";
		}
		return zeroes + this->catNum;
	}
	else{
		return this->catNum;
	}
}

//accessor that returns column 2
string Eclipse::getCanonPlate(){
	return this->canonPlate;
}

//accessor that returns column 3
string Eclipse::getCalYear(){
	return this->calYear;
}

//accessor that returns column 4
string Eclipse::getCalMonth(){
	return this->calMonth;
}

//accessor that returns column 5
string Eclipse::getCalDate(){
	return this->calDate;
}

//accessor that returns column 6
string Eclipse::getTD(){
	return this->tD;
}

//accessor that returns column 7
string Eclipse::getDT(){
	return this->dT;
}

//accessor that returns column 8
string Eclipse::getLunaNum(){
	return this->lunaNum;
}

//accessor that returns column 9
string Eclipse::getSarosNum(){
	return this->sarosNum;
}

//accessor that returns column 10
string Eclipse::getEclType(){
	return this->eclType;
}

//accessor that returns column 11
string Eclipse::getGamma(){
	return this->gamma;
}

//accessor that returns column 12
string Eclipse::getEclMag(){
	return this->eclMag;
}

//accessor that returns column 13
string Eclipse::getLatitude(){
	return this->latitude;
}

//accessor that returns column 14
string Eclipse::getLongitude(){
	return this->longitude;
}

//accessor that returns column 15
string Eclipse::getSunAlt(){
	return this->sunAlt;
}

//accessor that returns column 16
string Eclipse::getSunAzm(){
	return this->sunAzm;
}

//accessor that returns column 17
string Eclipse::getPathWidth(){
	return this->pathWidth;
}

//accessor that returns column 18
string Eclipse::getCentralDur(){
	return this->centralDur;
}

//overloaded ostream operator outputs the data string with spaces instead of the object's address in memory
ostream& operator<< (ostream& s, const Eclipse& e){
	s << e.dataSpaces;
	return s;
}

//overloaded equality operator sets each field equal to the corresponding field of the given eclipse
Eclipse Eclipse::operator=(const Eclipse& e){

	this->dataSpaces = e.dataSpaces;
	this->dataCommas = e.dataCommas;
	this->catNum = e.catNum;
	this->canonPlate = e.canonPlate;
	this->calYear = e.calYear;
	this->calMonth = e.calMonth;
	this->calDate = e.calDate;
	this->tD = e.tD;
	this->dT = e.dT;
	this->lunaNum = e.lunaNum;
	this->sarosNum = e.sarosNum;
	this->eclType = e.eclType;
	this->gamma = e.gamma;
	this->eclMag = e.eclMag;
	this->latitude = e.latitude;
	this->longitude = e.longitude;
	this->sunAlt = e.sunAlt;
	this->sunAzm = e.sunAzm;
	this->pathWidth = e.pathWidth;
	this->centralDur = e.centralDur;
	return *this;
}


bool Eclipse::operator>(const Eclipse& e){
	//try/catch is redundant here because for an eclipse object to even be created, we have already try/caught catNum
	try{
		if(stoi(this->catNum) > stoi(e.catNum)){
			return true;
		}
		else{
			return false;
		}
	}
	catch(invalid_argument& ia){
		cerr << "catNum is not an integer." << endl;
	}
}

bool Eclipse::operator<(const Eclipse& e){
	//try/catch is redundant here because for an eclipse object to even be created, we have already try/caught catNum
	try{
		if(stoi(this->catNum) < stoi(e.catNum)){
			return true;
		}
		else{
			return false;
		}
	}
	catch(invalid_argument& ia){
		cerr << "catNum is not an integer." << endl;
	}
}

bool Eclipse::operator>=(const Eclipse& e){
	//try/catch is redundant here because for an eclipse object to even be created, we have already try/caught catNum
	try{
		if(stoi(this->catNum) >= stoi(e.catNum)){
			return true;
		}
		else{
			return false;
		}
	}
	catch(invalid_argument& ia){
		cerr << "catNum is not an integer." << endl;
	}
}

bool Eclipse::operator<=(const Eclipse& e){
	//try/catch is redundant here because for an eclipse object to even be created, we have already try/caught catNum
	try{
		if(stoi(this->catNum) <= stoi(e.catNum)){
			return true;
		}
		else{
			return false;
		}
	}
	catch(invalid_argument& ia){
		cerr << "catNum is not an integer." << endl;
	}
}

bool Eclipse::operator==(const Eclipse& e){
	//try/catch is redundant here because for an eclipse object to even be created, we have already try/caught catNum
	try{
		if(stoi(this->catNum) == stoi(e.catNum)){
			return true;
		}
		else{
			return false;
		}
	}
	catch(invalid_argument& ia){
		cerr << "catNum is not an integer." << endl;
	}
}

//this function takes in the processed CSV-ready data String and separates it into the desired string
//this is used in the constructor to separate a data string into the 18 fields the eclipse object holds
string Eclipse::columnSeparator(string data, int columnNum, bool isPartial){

	//number of commas in the line
	int numCommas = 0;


	//the column we're looking for (not initialized bc we do that later)
	int desiredColumn;

	//set to the max possible values
	if(isPartial){
		desiredColumn = 16;
	}
	else{
		desiredColumn = 18;
	}

	for(int i = 0; i < data.length(); ++i){

		//increments numCommas to find the number of commas in the line
		if(data.at(i) == ','){
			++numCommas;
		}

		//uses three if statements, since the first and last columns aren't "sandwiched" by commas
		//returns everything before the first comma (the first column)
		if(data.at(i) == ',' && columnNum == 1){
			return(data.substr(0, i));
		}
		//returns the last column
		else if(data.at(i) == ',' && columnNum == desiredColumn && numCommas == columnNum - 1){
			return(data.substr(i + 1, data.length() - i - 1));
		}
		//returns the desired column
		else if(data.at(i) == ',' && numCommas == columnNum - 1){
			return(data.substr(i + 1, data.find(',', i + 1) - i - 1));
		}

	}

}

//this function determines whether or not an eclipse should have 16 or 18 columns depending on its type
bool Eclipse::columnLength(){

	string dataString = this->dataCommas;

	//finds where the eclipse type should be
	int numCommas = 0;
	int eclipseTypeIndex = 0;

	for(unsigned int m = 0; m < dataString.length();  ++m){
		//iterates through and counts commas
		if(dataString.at(m) == ','){
			++numCommas;
		}
		//if it hits 9 commas (10th column comes after 9th comma) it returns the next index
		if(dataString.at(m) == ',' && numCommas == 9){
			eclipseTypeIndex = m + 1;
		}

	}

	//determines length of eclipse
	if(dataString.at(eclipseTypeIndex) == 'P'){

		return true;		//P means partial, so we expect a partial eclipse and set the bool accordingly

	}
	else if(dataString.at(eclipseTypeIndex) != 'P'){

		return false;		//P means partial, so we expect a non-partial eclipse and set the bool accordingly

	}

}

//returns the element based on the given integer
string Eclipse::getColumnElement(int columnNum){
	if(columnNum == 1){
		return this->catNum;
	}
	if(columnNum == 2){
		return this->canonPlate;
	}
	if(columnNum == 3){
		return this->calYear;
	}
	if(columnNum == 4){
		return this->calMonth;
	}
	if(columnNum == 5){
		return this->calDate;
	}
	if(columnNum == 6){
		return this->tD;
	}
	if(columnNum == 7){
		return this->dT;
	}
	if(columnNum == 8){
		return this->lunaNum;
	}
	if(columnNum == 9){
		return this->sarosNum;
	}
	if(columnNum == 10){
		return this->eclType;
	}
	if(columnNum == 11){
		return this->gamma;
	}
	if(columnNum == 12){
		return this->eclMag;
	}
	if(columnNum == 13){
		return this->latitude;
	}
	if(columnNum == 14){
		return this->longitude;
	}
	if(columnNum == 15){
		return this->sunAlt;
	}
	if(columnNum == 16){
		return this->sunAzm;
	}
	if(columnNum == 17){
		return this->pathWidth;
	}
	if(columnNum == 18){
		return this->centralDur;
	}
}
}
