/*
 * Main.h
 *
 *  Created on: Oct 17, 2017
 *      Author: Alex
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "ResizeableArray.h"
#include "LinkedList.h"
#include "Eclipse.h"
#include "HashTable.h"
#include "AVLTree.h"

namespace std {

class Main {
public:
	//main method in constructor
	Main();
	~Main();

	//creates  single main object and the object executes all code
	int main();

	//data processing methods
	void merge(int left, int mid, int right, int columnNum);
	void mergeSort(int left, int right, int columnNum);
	int monthToInt(string month);
	int binarySearch(int left, int right, string key, int columnNum);
	ResizeableArray<Eclipse> find(int left, int right, string key, int columnNum);

	//error checking methods
	bool errorChecker(Eclipse e, int currentRow, int fileNum);
	bool numChecker(string num, char choice);
	string columnSeparator(string data, int columnNum, bool isPartial);

	//array and list functions
	LinkedList<Eclipse> arrayToList();
	int linkedListSortedOrder(Eclipse ecl);

private:
	//a list, hash table, and array to hold the eclipse objects
	ResizeableArray<Eclipse> dataArray;
	LinkedList<Eclipse> dataList;
	HashTable<Eclipse> dataTable;
	AVLTree<Eclipse> dataTree;
	//int showing which column dataArray is currently sorted on.  0 means it is unsorted
	int sortedColumn = 0;

};

} /* namespace std */

#endif /* MAIN_H_ */
