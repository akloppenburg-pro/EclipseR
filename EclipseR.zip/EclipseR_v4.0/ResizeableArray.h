/*
 * ResizeableArray.h
 *
 * A templated class designed to use a dynamically resized array to hold data of any type.  The array dynamically doubles
 * and halves its size as needed when objects are added to and removed from it.  The class also contains methods to replace
 * elements, display and retrieve the contents of the array, and track its length.
 *
 *  Created on: Oct 17, 2017
 *      Author: Alex
 */

#ifndef RESIZEABLEARRAY_H_
#define RESIZEABLEARRAY_H_
#include <iostream>
#include <iomanip>
#include <string>

namespace std {

template<typename T> class ResizeableArray {
private:

	//field to hold objects of any type
	T *data;

	//indicates the current max size of the resizeable array
	int currMax;

	//indicates the current size, or the element in use
	int currSize;

public:

	//overloaded operator to be used with any type of object
	//T operator= (const T& type){
	//	this->data = type.data;
	//	this->currMax = type.currMax;
	//	this->currSize = type.currSize;
	//	return *this;
	//}

	//constructor creates an array of size 10 with no elements in it
	ResizeableArray(){

		data = new T[10];
		currMax = 10;
		currSize = 0;

	}

	//destructor deletes the array and then sets all is fields to null or 0
	~ResizeableArray(){
		/*cout << "entered destructor" << endl;
		delete data;
		cout << "data deleted" << endl;
		data = nullptr;
		cout << "data set to null" << endl;
		currMax = 0;
		cout << "currmax set to 0" << endl;
		currSize = 0;
		cout << "currsize set to 0" << endl;*/
	}

	//adds an object to the next available position in the array, dynamically doubling the size if needed
	void add(T object){

		//check and see if dynamic resizing is necessary every time before we add
		if(currSize == currMax - 1){
			//store array data in a temporary array
			T* temp = data;

			//sets array equal to a new array twice its previous size
			data = new T[currMax * 2];

			//copies data over into the new, larger array
			for(int i = 0; i < currMax; ++i){
				data[i] = temp[i];
			}

			//sets currSize equal to twice what it was
			currMax *= 2;

			//deletes the temporary array to free up memory space
			delete[] temp;
		}

		//elementcounter will always be the last element in the array
		data[currSize] = object;
		++currSize;

	}

	//adds an object at the desired position, moving other elements and dynamically doubling the size if needed
	void addAt(T object, int index){

		if(index > currSize){
			cerr << "Index is out of bounds" << endl;
		}

		//check and see if dynamic resizing is necessary every time before we add
		if(currSize == currMax - 1){
			//store array data in a temporary array
			T* temp = data;

			//sets array equal to a new array twice its previous size
			data = new T[currMax * 2];

			//copies data over into the new, larger array
			for(int i = 0; i < currMax; ++i){
				data[i] = temp[i];
			}

			//sets currSize equal to twice what it was
			currMax *= 2;

			//deletes the temporary array to free up memory space
			delete[] temp;
		}

		for(int i = currSize - 1; i > index; --i){
			data[i] = data[i - 1];
		}

		++currSize;

	}

	//removes the element at a certain position, dynamically halving the size as needed
	void removeAt(int index){

		for(int i = index; i < currSize - 1; ++i){
			data[i] = data[i + 1];
		}

		//after the element is removed and the spot at the end of the array is zeroed out
		//decrement elementCounter accordingly
		--currSize;

		//if dynamic halving is needed, implements it
		if(currSize < currMax / 2){

			T* temp = data;

			//sets array equal to a new array half its previous size
			data = new T[currMax / 2];

			//Sets currSize equal to half what it was
			currMax /= 2;

			//copies data over into the new, larger array
			for(int i = 0; i < currMax; ++i){
				data[i] = temp[i];
			}

			//deletes the temporary array to free up memory space
			delete[] temp;
		}

	}

	//replaces the object at the given position with the given object
	void replaceAt(T object, int index){
		if(index > currSize){
			throw std::out_of_range("Desired element out of range.");
		}
		else{
			data[index] = object;
		}

	}

	//returns the object found at the given index
	T get(int index){

		return data[index];

	}

	//sends the array elements one by one to the given ostream, so as to be used with any type of output stream
	void display(ostream& anyStream){
		for(int p = 0; p < currSize; p++){
			anyStream << data[p] << endl;
		}
	}

	int length(){
		return currSize;
	}

	T* getArray(){
		return data;
	}

};

} /* namespace std */

#endif /* RESIZEABLEARRAY_H_ */
