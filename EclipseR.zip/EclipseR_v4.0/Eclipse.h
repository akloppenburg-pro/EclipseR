/*
 * Eclipse.h
 *
 * A class to hold an eclipse read in from a file and all its data, as well as methods to access, manipulate, and output
 * the data.
 *
 *  Created on: Oct 17, 2017
 *  Author: Alex
 */

#ifndef ECLIPSE_H_
#define ECLIPSE_H_

#include <string>

namespace std {

class Eclipse {
public:

	//constructors and destructor
	Eclipse(string dataString);
	Eclipse();
	Eclipse(const Eclipse& e);
	~Eclipse();

	//accessors
	string getDataSpaces();
	string getDataCommas();
	string getCatNum();
	string getCanonPlate();
	string getCalYear();
	string getCalMonth();
	string getCalDate();
	string getTD();
	string getDT();
	string getLunaNum();
	string getSarosNum();
	string getEclType();
	string getGamma();
	string getEclMag();
	string getLatitude();
	string getLongitude();
	string getSunAlt();
	string getSunAzm();
	string getPathWidth();
	string getCentralDur();

	//overloaded ostream and assignment operators
	friend ostream& operator<< (ostream& s, const Eclipse& e);
	Eclipse operator=(const Eclipse& e);
	//overloaded comparison operators
	bool operator>(const Eclipse& e);
	bool operator<(const Eclipse& e);
	bool operator<=(const Eclipse& e);
	bool operator>=(const Eclipse& e);
	bool operator==(const Eclipse& e);

	//misc methods
	bool columnLength();
	string columnSeparator(string data, int columnNum, bool isPartial);
	string getColumnElement(int columnNum);

private:
	//data fields
	string dataSpaces;
	string dataCommas;
	string catNum;
	string canonPlate;
	string calYear;
	string calMonth;
	string calDate;
	string tD;
	string dT;
	string lunaNum;
	string sarosNum;
	string eclType;
	string gamma;
	string eclMag;
	string latitude;
	string longitude;
	string sunAlt;
	string sunAzm;
	string pathWidth;
	string centralDur;
};

} /* namespace std */

#endif /* ECLIPSE_H_ */
