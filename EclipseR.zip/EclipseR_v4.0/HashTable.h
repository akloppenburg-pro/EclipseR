/*
 * C++ Program to Implement Hash Tables chaining
 * with Singly Linked Lists
 * code adapted from code found on
 */
#include<iostream>
#include<cstdlib>
#include<string>
#include<cstdio>
#include "LinkedList.h"
#include "Eclipse.h"
using namespace std;

/*
 * HashNode Class Declaration
 */
template <typename t>
class HashNode {

public:
	int key;
	t value;
	HashNode<t>* next;
	HashNode(int key, t value)
	{
		this->key = key;
		this->value = value;
		this->next = nullptr;
	}
};

/*
 * HashMap Class Declaration
 */
template <typename t>
class HashTable
{
public:
	HashTable();//empty constructor
	HashTable(ResizeableArray<t> array, LinkedList<t> list);
	~HashTable();//destructor
	int hashFunc(int key); //Hash Function
	void insert(int key, t value); //Insert element at key
	void remove(int key);//Removes element at key
	int getTableSize();
	int search(int key); //Searches for element at key
	void display(ostream& anyStream);//Prints out the buckets and overflow in the hash table
	void reallocateData(ResizeableArray<t> array, LinkedList<t> list);
	void displayLL(ostream& anyStream);

private:
	int tableSize;
	HashNode<t>** htable;
	LinkedList<t> embeddedLinkedList;
};


template <typename t>
HashTable<t>::HashTable() {
	this->tableSize = 128;
	this->htable = new HashNode<t>*[tableSize];
	for (int i = 0; i < tableSize; i++)
		htable[i] = nullptr;
	embeddedLinkedList = LinkedList<t>();
}

//code adapted from code provided by Cavan Gary
template <typename t>
HashTable<t>::HashTable(ResizeableArray<t> array, LinkedList<t> list) {
	this->tableSize = array.length();//TODO: check if its one too long
	this->htable = new HashNode<t>*[tableSize];
	for(int i = 0; i < tableSize; i++) {
		htable[i] = nullptr;//might not work for eclipses
	}

	int hashVal;
	int key;
	HashNode<t>* prev;
	HashNode<t>* entry;

	for(int j = 0; j < tableSize; j++) {
		hashVal = hashFunc(stoi(array.get(j).getColumnElement(1)));
		key = stoi(array.get(j).getColumnElement(1));
		prev = nullptr;
		entry = htable[hashVal];

		while (entry != nullptr) {
			prev = entry;
			entry = entry->next;
		}
		if (entry == nullptr) {
			entry = new HashNode<t>(key, array.get(j));
			if (prev == nullptr) {
				htable[hashVal] = entry;
			}
			else {
				prev->next = entry;
			}
		}
		else {
			entry->value = array.get(j);
		}
	}

	embeddedLinkedList = list;
}

template <typename t>
HashTable<t>::~HashTable() {
	for (int i = 0; i < tableSize; ++i)
	{
		HashNode<t>* entry = htable[i];
		while (entry != nullptr)
		{
			HashNode<t>* prev = entry;
			entry = entry->next;
			delete prev;
		}
	}
	delete[] htable;
}

template <typename t>
int HashTable<t>::hashFunc(int key) {
	return key % 10;
}

template <typename t>
void HashTable<t>::insert(int key, t value) {
	int hash_val = hashFunc(key);
	HashNode<t>* prev = nullptr;
	HashNode<t>* entry = htable[hash_val];
	while (entry != nullptr) {
		prev = entry;
		entry = entry->next;
	}
	if (entry == nullptr) {
		entry = new HashNode<t>(key, value);
		if (prev == nullptr) {
			htable[hash_val] = entry;
		}
		else {
			prev->next = entry;
		}
	}
	else {
		entry->value = value;
	}
}

template <typename t>
void HashTable<t>::remove(int key) {
	int hash_val = hashFunc(key);
	HashNode<t>* entry = htable[hash_val];
	HashNode<t>* prev = nullptr;
	if (entry == nullptr || entry->key != key)
	{
		cout<<"No Element found at key "<<key<<endl;
		return;
	}
	while (entry->next != nullptr)
	{
		prev = entry;
		entry = entry->next;
	}
	if (prev != nullptr)
	{
		prev->next = entry->next;
	}
	delete entry;
	cout<<"Element Deleted"<<endl;
}

template <typename t>
int HashTable<t>::getTableSize() {
	return this->tableSize;
}

template <typename t>
int HashTable<t>::search(int key) {
	bool flag = false;
	int hash_val = hashFunc(key);
	HashNode<t>* entry = htable[hash_val];
	while (entry != nullptr)
	{
		if (entry->key == key)
		{
			cout << entry->value << endl;
			flag = true;
		}
		entry = entry->next;
	}
	if (!flag)
		return -1;
}

//code adapted from code provided by Cavan Gary
template <typename t>
void HashTable<t>::display(ostream& anyStream) {

	for(int i = 0; i < tableSize; i++) {
		bool hasOverflow = false;
		int hash_val = i;
		HashNode<t>* entry = htable[hash_val];
		anyStream << endl << "Bucket " << hash_val << ": " ;//no endl

		if(entry == nullptr) {
			anyStream << "NULL" << endl;
		}

		while (entry != nullptr)
		{
			if(hasOverflow) {
				anyStream << "OVERFLOW: " << entry->value << endl;
				entry = entry->next;
				continue;
			}

			anyStream << entry->value<< endl;
			hasOverflow = true;

			entry = entry->next;
		}

	}
}

//code adapted from code provided by Cavan Gary
template <typename t>
void HashTable<t>::reallocateData(ResizeableArray<t> array, LinkedList<t> list) {
	this->tableSize = array.length();//TODO: check if its one too long
	this->htable = new HashNode<t>*[tableSize];
	for(int i = 0; i < tableSize; i++) {
		htable[i] = nullptr;//might not work for eclipses
	}

	int hashVal;
	int key;
	HashNode<t>* prev;
	HashNode<t>* entry;

	for(int j = 0; j < tableSize; j++) {
		hashVal = hashFunc(stoi(array.get(j).getColumnElement(1)));
		key = stoi(array.get(j).getColumnElement(1));
		prev = nullptr;
		entry = htable[hashVal];

		while (entry != nullptr) {
			prev = entry;
			entry = entry->next;
		}
		if (entry == nullptr) {
			entry = new HashNode<t>(key, array.get(j));
			if (prev == nullptr) {
				htable[hashVal] = entry;
			}
			else {
				prev->next = entry;
			}
		}
		else {
			entry->value = array.get(j);
		}
	}

	embeddedLinkedList = list;
}

template <typename t>
void HashTable<t>::displayLL(ostream& anyStream){
	embeddedLinkedList.display(anyStream);
}
